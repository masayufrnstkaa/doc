class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-primary"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function DokumenApp() {
  try {
    const [searchTerm, setSearchTerm] = React.useState('');
    const [documents, setDocuments] = React.useState([]);

    React.useEffect(() => {
      const documentsWithType = mockDocuments.map(item => ({...item, type: 'dokumen'}));
      setDocuments(documentsWithType);
    }, []);

    const filteredDocuments = documents.filter(doc => 
      doc.title.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="min-h-screen bg-[var(--background-color)]" data-name="dokumen-app" data-file="dokumen-app.js">
        <Header />
        
        <div className="bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
          <div className="container mx-auto px-4 text-center">
            <div className="icon-file-text text-4xl text-blue-600 mb-4"></div>
            <h1 className="text-3xl md:text-4xl font-bold text-[var(--text-primary)] mb-4">
              Dokumen
            </h1>
            <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">
              Kumpulan panduan, kebijakan, SOP, dan dokumentasi penting untuk referensi dan implementasi.
            </p>
          </div>
        </div>
        
        <main className="container mx-auto px-4 py-8">
          <div className="card mb-8">
            <div className="relative">
              <div className="icon-search absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-secondary)]"></div>
              <input
                type="text"
                placeholder="Cari dokumen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDocuments.map(doc => (
              <DocumentCard key={doc.id} document={doc} />
            ))}
          </div>
          
          {filteredDocuments.length === 0 && (
            <div className="text-center py-12">
              <div className="icon-file-text text-4xl text-[var(--secondary-color)] mb-4"></div>
              <p className="text-[var(--text-secondary)]">Tidak ada dokumen yang ditemukan</p>
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('DokumenApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <DokumenApp />
  </ErrorBoundary>
);