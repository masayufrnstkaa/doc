const express = require("express")
const mysql = require("mysql")

const app = express()

const db = mysql.createConnection({
    host: "localhost",
    database: "dokumen",
    user: "root",
    password: ""
})

db.connect((err) => {
    if (err) throw err
    console.log("Connected to the database!")

    const sql = "SELECT * FROM user"
    db.query(sql, (err, results) => {
        // console.log("Data from user table:", results)
        const users = JSON.parse(JSON.stringify(results))
        console.log("Users:", users)
        app.get("/", (req, res) => {
            res.send(users)
        })
    })
})

// app.get("/", (req, res) => {
//     res.send("Hello, World!")
// })

app.listen(5000, () => {
    console.log("Server is running on port 5000")
})