class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-primary"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function AdminDashboardApp() {
  try {
    const [activeTab, setActiveTab] = React.useState('dashboard');
    const [documents, setDocuments] = React.useState([]);

    React.useEffect(() => {
      // Check admin authentication
      const token = localStorage.getItem('adminToken');
      if (!token) {
        window.location.href = 'admin-login.html';
        return;
      }

      // Load mock data
      const allDocs = [
        ...mockProducts.map(item => ({...item, type: 'produk'})),
        ...mockDocuments.map(item => ({...item, type: 'dokumen'})),
        ...mockBulletins.map(item => ({...item, type: 'buletin'}))
      ];
      setDocuments(allDocs);
    }, []);

    const handleLogout = () => {
      localStorage.removeItem('adminToken');
      window.location.href = 'admin-login.html';
    };

    return (
      <div className="min-h-screen bg-[var(--background-color)]" data-name="admin-dashboard" data-file="admin-dashboard-app.js">
        <AdminHeader activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} />
        
        <main className="container mx-auto px-4 py-8">
          {activeTab === 'dashboard' && (
            <div>
              <h1 className="text-3xl font-bold text-[var(--text-primary)] mb-8">Dashboard Admin</h1>
              <AdminStats documents={documents} />
            </div>
          )}
          
          {activeTab === 'documents' && (
            <div>
              <h1 className="text-3xl font-bold text-[var(--text-primary)] mb-8">Kelola Dokumen</h1>
              <AdminDocumentList documents={documents} setDocuments={setDocuments} />
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('AdminDashboardApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <AdminDashboardApp />
  </ErrorBoundary>
);