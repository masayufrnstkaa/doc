// Mock data untuk demonstrasi
const mockProducts = [
  {
    id: 1,
    title: "Sistem Manajemen Inventory",
    description: "Aplikasi untuk mengelola stok barang dan inventory perusahaan dengan fitur real-time monitoring.",
    date: "2024-01-15",
    fileType: "PDF",
    fileUrl: "#"
  },
  {
    id: 2,
    title: "Platform E-Learning",
    description: "Solusi pembelajaran online dengan fitur video conference, quiz, dan tracking progress siswa.",
    date: "2024-01-20",
    fileType: "DOCX",
    fileUrl: "#"
  },
  {
    id: 3,
    title: "Aplikasi Mobile Banking",
    description: "Aplikasi perbankan mobile dengan keamanan tinggi dan interface yang user-friendly.",
    date: "2024-02-01",
    fileType: "PDF",
    fileUrl: "#"
  }
];

const mockDocuments = [
  {
    id: 1,
    title: "Panduan Implementasi ISO 27001",
    description: "Dokumen lengkap mengenai standar keamanan informasi dan langkah-langkah implementasinya.",
    date: "2024-01-10",
    fileType: "PDF",
    fileUrl: "#"
  },
  {
    id: 2,
    title: "Kebijakan Keamanan Data",
    description: "Dokumen kebijakan perusahaan terkait pengelolaan dan keamanan data sensitif.",
    date: "2024-01-25",
    fileType: "DOCX",
    fileUrl: "#"
  },
  {
    id: 3,
    title: "SOP Pengembangan Aplikasi",
    description: "Standard Operating Procedure untuk proses pengembangan aplikasi dari planning hingga deployment.",
    date: "2024-02-05",
    fileType: "PDF",
    fileUrl: "#"
  },
  {
    id: 4,
    title: "Manual User Testing",
    description: "Panduan lengkap untuk melakukan user testing dan analisis feedback pengguna.",
    date: "2024-02-12",
    fileType: "DOCX",
    fileUrl: "#"
  }
];

const mockBulletins = [
  {
    id: 1,
    title: "Buletin Teknologi Q1 2024",
    description: "Update terbaru mengenai tren teknologi, inovasi, dan perkembangan industri IT di kuartal pertama 2024.",
    date: "2024-03-01",
    fileType: "PDF",
    fileUrl: "#"
  },
  {
    id: 2,
    title: "Newsletter Keamanan Cyber",
    description: "Informasi terkini tentang ancaman keamanan cyber dan tips proteksi untuk perusahaan.",
    date: "2024-02-15",
    fileType: "PDF",
    fileUrl: "#"
  },
  {
    id: 3,
    title: "Buletin Pengembangan Tim",
    description: "Tips dan strategi untuk pengembangan tim, produktivitas, dan kolaborasi yang efektif.",
    date: "2024-02-28",
    fileType: "PDF",
    fileUrl: "#"
  }
];