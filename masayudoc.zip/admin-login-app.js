class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-primary"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function AdminLoginApp() {
  try {
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [isLoading, setIsLoading] = React.useState(false);
    const [error, setError] = React.useState('');

    const handleLogin = async (e) => {
      e.preventDefault();
      setIsLoading(true);
      setError('');

      // Simulate login process
      setTimeout(() => {
        if (email === 'admin@docstorage.com' && password === 'admin123') {
          localStorage.setItem('adminToken', 'mock-token');
          window.location.href = 'admin-dashboard.html';
        } else {
          setError('Email atau password salah');
        }
        setIsLoading(false);
      }, 1000);
    };

    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100" data-name="admin-login" data-file="admin-login-app.js">
        <div className="max-w-md w-full mx-4">
          <div className="text-center mb-8">
            <div className="icon-shield text-4xl text-[var(--primary-color)] mb-4"></div>
            <h1 className="text-3xl font-bold text-[var(--text-primary)]">Admin Login</h1>
            <p className="text-[var(--text-secondary)] mt-2">Masuk ke panel administrator</p>
          </div>

          <div className="card">
            <form onSubmit={handleLogin}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
                  placeholder="admin@docstorage.com"
                  required
                />
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
                  placeholder="Masukkan password"
                  required
                />
              </div>

              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full btn btn-primary"
              >
                {isLoading ? (
                  <div className="icon-loader text-lg animate-spin mr-2 inline-block"></div>
                ) : (
                  <div className="icon-log-in text-lg mr-2 inline-block"></div>
                )}
                {isLoading ? 'Memproses...' : 'Masuk'}
              </button>
            </form>

            <div className="mt-6 pt-6 border-t border-[var(--border-color)]">
              <div className="text-center">
                <a
                  href="index.html"
                  className="text-[var(--primary-color)] hover:text-[var(--primary-hover)] text-sm font-medium"
                >
                  ← Kembali ke Beranda
                </a>
              </div>
              
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-700">
                  <strong>Demo Login:</strong><br/>
                  Email: admin@docstorage.com<br/>
                  Password: admin123
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AdminLoginApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <AdminLoginApp />
  </ErrorBoundary>
);
