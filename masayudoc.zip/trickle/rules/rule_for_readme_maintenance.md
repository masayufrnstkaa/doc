When project is updated or modified

- Always check if README.md in trickle/notes needs to be updated
- Update README.md content to reflect new features, changes, or structure
- Keep README.md concise but comprehensive
- Include any new pages, components, or functionality added
- Update technology stack information if changed
- Maintain demo credentials and usage instructions