# Digital Document Storage Platform

Platform penyimpanan digital untuk produk, dokumen, dan buletin dengan akses publik untuk user dan panel admin untuk pengelolaan.

## Fitur Utama

### 👤 User Umum (Tanpa Login)
- Mengakses dan melihat semua kategori: Produk, Dokumen, Buletin
- Mencari dan memfilter dokumen berdasarkan kategori
- Mengunduh file dokumen
- Melihat detail setiap item

### 🔐 Admin (Login Required)
- Dashboard dengan statistik dokumen
- CRUD (Create, Read, Update, Delete) untuk semua kategori dengan form lengkap
- Upload dan manajemen file dengan drag & drop interface
- Filter dan pencarian dokumen
- Validasi form dan handling error
- Logout sistem

## Struktur Website

### Halaman Publik
- `index.html` - Beranda utama dengan semua dokumen
- `produk.html` - Halaman khusus untuk produk
- `dokumen.html` - Halaman khusus untuk dokumen
- `buletin.html` - Halaman khusus untuk buletin
- `admin-login.html` - Halaman login admin

### Halaman Admin
- `admin-dashboard.html` - Dashboard admin dengan statistik dan manajemen

## Teknologi
- React 18 (Production)
- TailwindCSS untuk styling
- Lucide Icons untuk ikon
- Responsive design

## Kredensial Admin Demo
- Email: admin@docstorage.com
- Password: admin123

## Kategori Dokumen
1. **Produk** - Aplikasi dan sistem yang dikembangkan
2. **Dokumen** - Panduan, kebijakan, dan SOP
3. **Buletin** - Newsletter dan update berkala

## Catatan Pengembangan
- Menggunakan mock data untuk demonstrasi
- File upload disimulasikan dengan alert
- Autentikasi menggunakan localStorage untuk demo