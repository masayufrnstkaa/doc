class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-primary"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function BuletinApp() {
  try {
    const [searchTerm, setSearchTerm] = React.useState('');
    const [bulletins, setBulletins] = React.useState([]);

    React.useEffect(() => {
      const bulletinsWithType = mockBulletins.map(item => ({...item, type: 'buletin'}));
      setBulletins(bulletinsWithType);
    }, []);

    const filteredBulletins = bulletins.filter(bulletin => 
      bulletin.title.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="min-h-screen bg-[var(--background-color)]" data-name="buletin-app" data-file="buletin-app.js">
        <Header />
        
        <div className="bg-gradient-to-br from-purple-50 to-violet-100 py-12">
          <div className="container mx-auto px-4 text-center">
            <div className="icon-book-open text-4xl text-purple-600 mb-4"></div>
            <h1 className="text-3xl md:text-4xl font-bold text-[var(--text-primary)] mb-4">
              Buletin
            </h1>
            <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">
              Newsletter dan update berkala dengan informasi terkini tentang teknologi, inovasi, dan perkembangan terbaru.
            </p>
          </div>
        </div>
        
        <main className="container mx-auto px-4 py-8">
          <div className="card mb-8">
            <div className="relative">
              <div className="icon-search absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-secondary)]"></div>
              <input
                type="text"
                placeholder="Cari buletin..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBulletins.map(bulletin => (
              <DocumentCard key={bulletin.id} document={bulletin} />
            ))}
          </div>
          
          {filteredBulletins.length === 0 && (
            <div className="text-center py-12">
              <div className="icon-book-open text-4xl text-[var(--secondary-color)] mb-4"></div>
              <p className="text-[var(--text-secondary)]">Tidak ada buletin yang ditemukan</p>
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('BuletinApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <BuletinApp />
  </ErrorBoundary>
);