class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-primary"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function ProdukApp() {
  try {
    const [searchTerm, setSearchTerm] = React.useState('');
    const [products, setProducts] = React.useState([]);

    React.useEffect(() => {
      const productsWithType = mockProducts.map(item => ({...item, type: 'produk'}));
      setProducts(productsWithType);
    }, []);

    const filteredProducts = products.filter(product => 
      product.title.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="min-h-screen bg-[var(--background-color)]" data-name="produk-app" data-file="produk-app.js">
        <Header />
        
        <div className="bg-gradient-to-br from-green-50 to-emerald-100 py-12">
          <div className="container mx-auto px-4 text-center">
            <div className="icon-package text-4xl text-green-600 mb-4"></div>
            <h1 className="text-3xl md:text-4xl font-bold text-[var(--text-primary)] mb-4">
              Produk Kami
            </h1>
            <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">
              Koleksi aplikasi dan sistem yang telah dikembangkan untuk berbagai kebutuhan bisnis dan teknologi.
            </p>
          </div>
        </div>
        
        <main className="container mx-auto px-4 py-8">
          <div className="card mb-8">
            <div className="relative">
              <div className="icon-search absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-secondary)]"></div>
              <input
                type="text"
                placeholder="Cari produk..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map(product => (
              <DocumentCard key={product.id} document={product} />
            ))}
          </div>
          
          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <div className="icon-package text-4xl text-[var(--secondary-color)] mb-4"></div>
              <p className="text-[var(--text-secondary)]">Tidak ada produk yang ditemukan</p>
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('ProdukApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <ProdukApp />
  </ErrorBoundary>
);