function DocumentCard({ document }) {
  try {
    const getTypeIcon = (type) => {
      switch (type) {
        case 'produk': return 'package';
        case 'dokumen': return 'file-text';
        case 'buletin': return 'book-open';
        default: return 'file';
      }
    };

    const getTypeColor = (type) => {
      switch (type) {
        case 'produk': return 'text-green-600 bg-green-100';
        case 'dokumen': return 'text-blue-600 bg-blue-100';
        case 'buletin': return 'text-purple-600 bg-purple-100';
        default: return 'text-gray-600 bg-gray-100';
      }
    };

    const handleDownload = () => {
      // Simulate file download
      alert(`Mengunduh: ${document.title}`);
    };

    return (
      <div className="card hover:shadow-md transition-shadow duration-200" data-name="document-card" data-file="components/DocumentCard.js">
        <div className="flex items-start justify-between mb-4">
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getTypeColor(document.type)}`}>
            <div className={`icon-${getTypeIcon(document.type)} text-xl`}></div>
          </div>
          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getTypeColor(document.type)}`}>
            {document.type.charAt(0).toUpperCase() + document.type.slice(1)}
          </span>
        </div>
        
        <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-2 line-clamp-2">
          {document.title}
        </h3>
        
        <p className="text-[var(--text-secondary)] text-sm mb-4 line-clamp-3">
          {document.description}
        </p>
        
        <div className="flex items-center justify-between text-xs text-[var(--text-secondary)] mb-4">
          <span className="flex items-center">
            <div className="icon-calendar text-sm mr-1"></div>
            {new Date(document.date).toLocaleDateString('id-ID')}
          </span>
          <span className="flex items-center">
            <div className="icon-file text-sm mr-1"></div>
            {document.fileType}
          </span>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handleDownload}
            className="flex-1 btn btn-primary text-sm"
          >
            <div className="icon-download text-sm mr-2 inline-block"></div>
            Unduh
          </button>
          <a 
            href={`detail.html?type=${document.type}&id=${document.id}`}
            className="btn btn-secondary text-sm px-4"
          >
            <div className="icon-eye text-sm"></div>
          </a>
        </div>
      </div>
    );
  } catch (error) {
    console.error('DocumentCard component error:', error);
    return null;
  }
}