function AdminHeader({ activeTab, setActiveTab, onLogout }) {
  try {
    const tabs = [
      { id: 'dashboard', name: 'Dashboard', icon: 'layout-dashboard' },
      { id: 'documents', name: 'Kelola Dokumen', icon: 'file-text' }
    ];

    return (
      <nav className="navbar" data-name="admin-header" data-file="components/AdminHeader.js">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="icon-shield text-2xl text-[var(--primary-color)] mr-3"></div>
              <span className="text-xl font-bold text-[var(--text-primary)]">Admin Panel</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center ${
                    activeTab === tab.id 
                      ? 'text-[var(--primary-color)] bg-blue-50' 
                      : 'text-[var(--text-secondary)] hover:text-[var(--primary-color)]'
                  }`}
                >
                  <div className={`icon-${tab.icon} text-sm mr-2`}></div>
                  {tab.name}
                </button>
              ))}
              
              <div className="flex items-center space-x-4">
                <a
                  href="index.html"
                  className="text-[var(--text-secondary)] hover:text-[var(--primary-color)] text-sm"
                >
                  Lihat Website
                </a>
                <button
                  onClick={onLogout}
                  className="btn btn-danger text-sm"
                >
                  <div className="icon-log-out text-sm mr-2 inline-block"></div>
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>
    );
  } catch (error) {
    console.error('AdminHeader component error:', error);
    return null;
  }
}