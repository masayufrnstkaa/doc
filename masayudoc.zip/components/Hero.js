function Hero() {
  try {
    return (
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-16" data-name="hero" data-file="components/Hero.js">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-[var(--text-primary)] mb-6">
              Platform Penyimpanan
              <span className="text-[var(--primary-color)]"> Dokumen Digital</span>
            </h1>
            <p className="text-xl text-[var(--text-secondary)] mb-8">
              Akses mudah ke produk, dokumen, dan buletin. Temukan dan unduh file yang Anda butuhkan dengan cepat dan aman.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="#documents" className="btn btn-primary text-lg px-8 py-3">
                <div className="icon-search text-lg mr-2 inline-block"></div>
                Jelajahi Dokumen
              </a>
              <a href="admin-login.html" className="btn btn-secondary text-lg px-8 py-3">
                <div className="icon-shield text-lg mr-2 inline-block"></div>
                Admin Login
              </a>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}