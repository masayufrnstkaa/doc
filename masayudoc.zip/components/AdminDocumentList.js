function AdminDocumentList({ documents, setDocuments }) {
  try {
    const [showModal, setShowModal] = React.useState(false);
    const [editingDoc, setEditingDoc] = React.useState(null);
    const [filterType, setFilterType] = React.useState('all');
    const [formData, setFormData] = React.useState({
      title: '',
      description: '',
      type: 'dokumen',
      fileType: 'PDF'
    });
    const [isSubmitting, setIsSubmitting] = React.useState(false);

    const filteredDocs = documents.filter(doc => 
      filterType === 'all' || doc.type === filterType
    );

    React.useEffect(() => {
      if (editingDoc) {
        setFormData({
          title: editingDoc.title,
          description: editingDoc.description,
          type: editingDoc.type,
          fileType: editingDoc.fileType
        });
      } else {
        setFormData({
          title: '',
          description: '',
          type: 'dokumen',
          fileType: 'PDF'
        });
      }
    }, [editingDoc]);

    const handleDelete = (id) => {
      if (confirm('Apakah Anda yakin ingin menghapus dokumen ini?')) {
        setDocuments(docs => docs.filter(doc => doc.id !== id));
      }
    };

    const handleEdit = (doc) => {
      setEditingDoc(doc);
      setShowModal(true);
    };

    const handleAdd = () => {
      setEditingDoc(null);
      setShowModal(true);
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      setIsSubmitting(true);

      try {
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));

        if (editingDoc) {
          // Update existing document
          setDocuments(docs => docs.map(doc => 
            doc.id === editingDoc.id 
              ? { ...doc, ...formData, date: doc.date }
              : doc
          ));
        } else {
          // Add new document
          const newDoc = {
            id: Math.max(...documents.map(d => d.id)) + 1,
            ...formData,
            date: new Date().toISOString().split('T')[0],
            fileUrl: '#'
          };
          setDocuments(docs => [...docs, newDoc]);
        }

        setShowModal(false);
        setEditingDoc(null);
      } catch (error) {
        console.error('Error saving document:', error);
      } finally {
        setIsSubmitting(false);
      }
    };

    const handleInputChange = (e) => {
      const { name, value } = e.target;
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    };

    const handleCloseModal = () => {
      setShowModal(false);
      setEditingDoc(null);
    };

    return (
      <div data-name="admin-document-list" data-file="components/AdminDocumentList.js">
        <div className="flex justify-between items-center mb-6">
          <div className="flex gap-4">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
            >
              <option value="all">Semua Kategori</option>
              <option value="produk">Produk</option>
              <option value="dokumen">Dokumen</option>
              <option value="buletin">Buletin</option>
            </select>
          </div>
          <button
            onClick={handleAdd}
            className="btn btn-primary"
          >
            <div className="icon-plus text-sm mr-2 inline-block"></div>
            Tambah Dokumen
          </button>
        </div>

        <div className="card">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[var(--border-color)]">
                  <th className="text-left py-3 px-4 font-medium text-[var(--text-secondary)]">Judul</th>
                  <th className="text-left py-3 px-4 font-medium text-[var(--text-secondary)]">Kategori</th>
                  <th className="text-left py-3 px-4 font-medium text-[var(--text-secondary)]">Tanggal</th>
                  <th className="text-left py-3 px-4 font-medium text-[var(--text-secondary)]">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredDocs.map((doc) => (
                  <tr key={doc.id} className="border-b border-[var(--border-color)] hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium text-[var(--text-primary)]">{doc.title}</p>
                        <p className="text-sm text-[var(--text-secondary)] truncate">{doc.description}</p>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        doc.type === 'produk' ? 'text-green-600 bg-green-100' :
                        doc.type === 'dokumen' ? 'text-blue-600 bg-blue-100' :
                        'text-purple-600 bg-purple-100'
                      }`}>
                        {doc.type.charAt(0).toUpperCase() + doc.type.slice(1)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-[var(--text-secondary)]">
                      {new Date(doc.date).toLocaleDateString('id-ID')}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEdit(doc)}
                          className="text-[var(--primary-color)] hover:text-[var(--primary-hover)]"
                        >
                          <div className="icon-edit text-sm"></div>
                        </button>
                        <button
                          onClick={() => handleDelete(doc.id)}
                          className="text-[var(--danger-color)] hover:text-red-600"
                        >
                          <div className="icon-trash text-sm"></div>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Document Form Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-lg">
              <h3 className="text-xl font-bold mb-6">
                {editingDoc ? 'Edit Dokumen' : 'Tambah Dokumen Baru'}
              </h3>
              
              <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                      Judul Dokumen
                    </label>
                    <input
                      type="text"
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
                      placeholder="Masukkan judul dokumen"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                      Deskripsi
                    </label>
                    <textarea
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      rows="3"
                      className="w-full px-3 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
                      placeholder="Deskripsi dokumen"
                      required
                    ></textarea>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                        Kategori
                      </label>
                      <select
                        name="type"
                        value={formData.type}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
                        required
                      >
                        <option value="dokumen">Dokumen</option>
                        <option value="produk">Produk</option>
                        <option value="buletin">Buletin</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                        Tipe File
                      </label>
                      <select
                        name="fileType"
                        value={formData.fileType}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
                        required
                      >
                        <option value="PDF">PDF</option>
                        <option value="DOCX">DOCX</option>
                        <option value="XLSX">XLSX</option>
                        <option value="PPTX">PPTX</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                      File Upload
                    </label>
                    <div className="border-2 border-dashed border-[var(--border-color)] rounded-lg p-6 text-center">
                      <div className="icon-upload text-2xl text-[var(--text-secondary)] mb-2"></div>
                      <p className="text-sm text-[var(--text-secondary)]">
                        Klik untuk upload file atau drag & drop
                      </p>
                      <input
                        type="file"
                        className="hidden"
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    type="button"
                    onClick={handleCloseModal}
                    className="flex-1 btn btn-secondary"
                    disabled={isSubmitting}
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="flex-1 btn btn-primary"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <div className="icon-loader text-sm mr-2 inline-block animate-spin"></div>
                        Menyimpan...
                      </>
                    ) : (
                      <>
                        <div className="icon-save text-sm mr-2 inline-block"></div>
                        {editingDoc ? 'Update' : 'Simpan'}
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('AdminDocumentList component error:', error);
    return null;
  }
}
