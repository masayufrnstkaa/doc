function SearchFilter({ searchTerm, setSearchTerm, selectedCategory, setSelectedCategory }) {
  try {
    const categories = [
      { value: 'all', label: 'Semua Kategori' },
      { value: 'produk', label: 'Produk' },
      { value: 'dokumen', label: 'Dokumen' },
      { value: 'buletin', label: 'Buletin' }
    ];

    return (
      <div className="card" data-name="search-filter" data-file="components/SearchFilter.js" id="documents">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <div className="icon-search absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-secondary)]"></div>
              <input
                type="text"
                placeholder="Cari dokumen, produk, atau buletin..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="md:w-48">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-4 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent bg-white"
            >
              {categories.map(category => (
                <option key={category.value} value={category.value}>
                  {category.label}
                </option>
              ))}
            </select>
          </div>
          
          <button 
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
            }}
            className="btn btn-secondary whitespace-nowrap"
          >
            <div className="icon-refresh-cw text-sm mr-2 inline-block"></div>
            Reset
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('SearchFilter component error:', error);
    return null;
  }
}