function Header() {
  try {
    const [isOpen, setIsOpen] = React.useState(false);
    
    const navigation = [
      { name: 'Beranda', href: 'index.html', current: window.location.pathname.includes('index.html') || window.location.pathname === '/' },
      { name: 'Produk', href: 'produk.html', current: window.location.pathname.includes('produk.html') },
      { name: 'Dokumen', href: 'dokumen.html', current: window.location.pathname.includes('dokumen.html') },
      { name: 'Buletin', href: 'buletin.html', current: window.location.pathname.includes('buletin.html') }
    ];

    return (
      <nav className="navbar" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="icon-folder text-2xl text-[var(--primary-color)] mr-3"></div>
              <span className="text-xl font-bold text-[var(--text-primary)]">DocStorage</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="flex items-center space-x-8">
                {navigation.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      item.current 
                        ? 'text-[var(--primary-color)] bg-blue-50' 
                        : 'text-[var(--text-secondary)] hover:text-[var(--primary-color)]'
                    }`}
                  >
                    {item.name}
                  </a>
                ))}
                <a
                  href="admin-login.html"
                  className="btn btn-primary text-sm"
                >
                  Login Admin
                </a>
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
              >
                <div className={`icon-${isOpen ? 'x' : 'menu'} text-xl`}></div>
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 border-t border-[var(--border-color)]">
                {navigation.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className={`block px-3 py-2 rounded-md text-base font-medium ${
                      item.current 
                        ? 'text-[var(--primary-color)] bg-blue-50' 
                        : 'text-[var(--text-secondary)] hover:text-[var(--primary-color)]'
                    }`}
                  >
                    {item.name}
                  </a>
                ))}
                <a
                  href="admin-login.html"
                  className="block w-full text-left btn btn-primary mt-4"
                >
                  Login Admin
                </a>
              </div>
            </div>
          )}
        </div>
      </nav>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}